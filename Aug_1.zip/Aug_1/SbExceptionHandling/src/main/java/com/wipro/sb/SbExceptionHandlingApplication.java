package com.wipro.sb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbExceptionHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbExceptionHandlingApplication.class, args);
	}

}
