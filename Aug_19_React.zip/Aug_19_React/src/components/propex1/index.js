import propex1 from "./propex1"
export default propex1;
