import employupdate from "./employupdate"
export default employupdate;
