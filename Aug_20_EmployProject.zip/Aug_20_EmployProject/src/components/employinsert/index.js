import employinsert from "./employinsert"
export default employinsert;
