import fc3 from "./fc3"
export default fc3;
