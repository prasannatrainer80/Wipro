import React, {Component} from 'react';
import './fc1.scss'
// import { connect } from "react-redux";
// import { bindActionCreators } from "redux";
// import * as fc1Actions from "../../store/fc1/actions";

const fc1 = () => {
  return (
    <div>
      <p>Welcome to Functional Components...</p>
      <p>This is My First Functional Component...</p>
      <p>Thank You All...</p>
    </div>
  )
}
export default fc1;
