import logo from './logo.svg';
import './App.css';
import Basic from './Basic';
import Test from './Test';
function App() {
  return (
    <div className="App">
      <Basic /> <br/>
      <Test />
    </div>
  );
}

export default App;
