package com.example.demo;

public enum WalSource {
	PAYTM, CREDIT_CARD,DEBIT_CARD
}
