import customerpending from "./customerpending"
export default customerpending;
