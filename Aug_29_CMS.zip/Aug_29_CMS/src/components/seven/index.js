import seven from "./seven"
export default seven;
