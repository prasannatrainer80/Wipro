package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebFlux4MysqlDbExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebFlux4MysqlDbExampleApplication.class, args);
	}

}
