package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebFlux4RoutingApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebFlux4RoutingApplication.class, args);
	}

}
